# Bookstore Management System — Sprint 1 Package

This package contains the Sprint 1 deliverables for the group project.

## Contents
```
CS492_GP2/
  docs/                      # Planning doc, Project doc, Retrospective
  backend/                   # Flask API (Angel)
  frontend/                  # Static web UI (Matthew)
  README.md                  # You are here
  run.bat                    # One-click run (Windows)
  run.sh                     # One-click run (macOS/Linux)
  .env.example               # Example environment variables (no secrets)
```

## How to Run (Professor Instructions)

> Tested on Python 3.11+. No Node build is required for Sprint 1.

1. **Create and activate a virtual environment**
   - **Windows (PowerShell)**
     ```powershell
     python -m venv venv
     .\venv\Scripts\Activate.ps1
     ```
   - **macOS/Linux (bash/zsh)**
     ```bash
     python3 -m venv venv
     source venv/bin/activate
     ```

2. **Install dependencies**
   ```bash
   pip install -r backend/requirements.txt
   ```

3. **Run the backend**
   ```bash
   python backend/app.py
   ```
   The API will start on `http://localhost:5000` (unless configured otherwise).

4. **Open the frontend**
   - Option A (static): open `frontend/index.html` in your browser.
   - Option B (served by Flask, if configured): visit `http://localhost:5000`.

## Demo Accounts (Seeded for Sprint 1)
- **Admin:** username `admin` / password `admin123`
- **User:**  username `user` / password `user123`
*(Emails are seeded as well: admin@bookstore.com, user@bookstore.com, but login requires username.)*

## Sprint 1 Functionality Included
- User registration and login (JWT-based, username + password)
- Role-based access control (admin vs. user)
- Books API: list, detail, create (admin), update (admin), delete (admin)
- Frontend scaffolding for login and book list pages

## Notes for Reviewers
- Secrets are **not** committed. See `.env.example` for required variables. Copy to `.env` if running locally.
- Database is seeded for demo. Seeding can be toggled via an environment variable if configured by the team.
- No `venv/`, `.db`, or other binaries are included per submission guidelines.
