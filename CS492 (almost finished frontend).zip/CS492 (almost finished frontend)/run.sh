#!/bin/bash
# One-click launcher for Bookstore Backend (macOS/Linux)

# Create venv if it doesn’t exist
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi

# Activate venv
source venv/bin/activate

# Install dependencies
pip install -r backend/requirements.txt

echo "=========================================="
echo "Bookstore Backend is starting..."
echo "Demo credentials:"
echo "  Admin -> username: admin , password: admin123"
echo "  User  -> username: user  , password: user123"
echo "=========================================="

# Run backend
python backend/app.py
