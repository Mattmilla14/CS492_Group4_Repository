# This is the main file for our bookstore backend with JWT authentication
# Clean version that should fix the NameError

# Import all the tools we need
from flask import Flask, request, jsonify
from flask_cors import CORS
from models import db, Book, User, bcrypt
from database import init_database
from auth import token_required, admin_required
from datetime import datetime, date
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Create our Flask application - THIS MUST COME BEFORE @app.route decorators
app = Flask(__name__)

# Configure CORS
CORS(app)

# Configure our database and security
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.join(basedir, "instance", "bookstore.db")}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Set secret keys from environment variables
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'fallback-secret-key-for-development')
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'fallback-jwt-key-for-development')

# Initialize extensions
db.init_app(app)
bcrypt.init_app(app)

# Create the instance directory if it doesn't exist
os.makedirs(os.path.join(basedir, 'instance'), exist_ok=True)

# Initialize database with sample data
init_database(app)

# ===============================
# AUTHENTICATION ENDPOINTS
# ===============================

@app.route('/api/register', methods=['POST'])
def register():
    """POST /api/register - Create new user account"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['username', 'email', 'password']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Check if username already exists
        if User.query.filter_by(username=data['username']).first():
            return jsonify({
                'success': False,
                'error': 'Username already exists'
            }), 400
        
        # Check if email already exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({
                'success': False,
                'error': 'Email already exists'
            }), 400
        
        # Create new user
        new_user = User(
            username=data['username'],
            email=data['email'],
            role=data.get('role', 'user')
        )
        new_user.set_password(data['password'])
        
        db.session.add(new_user)
        db.session.commit()
        
        # Generate token for the new user
        token = new_user.generate_token()
        
        return jsonify({
            'success': True,
            'message': 'User registered successfully',
            'user': new_user.to_dict(),
            'token': token
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/login', methods=['POST'])
def login():
    """POST /api/login - User authentication with debug logging"""
    try:
        print("=== LOGIN ATTEMPT DEBUG ===")
        data = request.get_json()
        print(f"Received data: {data}")
        
        # Validate required fields
        if not data.get('username') or not data.get('password'):
            print("ERROR: Missing username or password")
            return jsonify({
                'success': False,
                'error': 'Username and password are required'
            }), 400
        
        print(f"Looking for user: {data['username']}")
        
        # Find the user by username
        user = User.query.filter_by(username=data['username']).first()
        print(f"User found: {user}")
        
        if user:
            print("User exists, checking password...")
            password_valid = user.check_password(data['password'])
            print(f"Password valid: {password_valid}")
            
            if password_valid:
                print("Password correct, generating token...")
                # Generate a token for the user
                token = user.generate_token()
                print(f"Token generated: {token is not None}")
                
                if token:
                    print("SUCCESS: Login completed")
                    return jsonify({
                        'success': True,
                        'message': 'Login successful',
                        'user': user.to_dict(),
                        'token': token
                    }), 200
                else:
                    print("ERROR: Could not generate token")
                    return jsonify({
                        'success': False,
                        'error': 'Could not generate token'
                    }), 500
            else:
                print("ERROR: Invalid password")
        else:
            print("ERROR: User not found")
            
        return jsonify({
            'success': False,
            'error': 'Invalid username or password'
        }), 401
            
    except Exception as e:
        print(f"EXCEPTION in login: {str(e)}")
        print(f"Exception type: {type(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    """GET /api/profile - Get current user's profile (requires token)"""
    return jsonify({
        'success': True,
        'user': current_user.to_dict()
    }), 200

# ===============================
# BOOK ENDPOINTS
# ===============================

@app.route('/api/books', methods=['GET'])
def get_all_books():
    """GET /api/books - Get all books (public endpoint)"""
    try:
        books = Book.query.all()
        return jsonify({
            'success': True,
            'data': [book.to_dict() for book in books],
            'count': len(books)
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/books/<int:book_id>', methods=['GET'])
def get_book_by_id(book_id):
    """GET /api/books/1 - Get specific book (public endpoint)"""
    try:
        book = Book.query.get(book_id)
        if book is None:
            return jsonify({
                'success': False,
                'error': 'Book not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': book.to_dict()
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/books', methods=['POST'])
@token_required
@admin_required
def create_book(current_user):
    """POST /api/books - Create new book (admin only)"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'author', 'price']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Create new book
        new_book = Book(
            title=data['title'],
            author=data['author'],
            isbn=data.get('isbn'),
            price=float(data['price']),
            description=data.get('description'),
            genre=data.get('genre'),
            publication_date=datetime.strptime(data['publication_date'], '%Y-%m-%d').date() 
                            if data.get('publication_date') else None,
            stock_quantity=data.get('stock_quantity', 0)
        )
        
        db.session.add(new_book)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': new_book.to_dict(),
            'message': 'Book created successfully',
            'created_by': current_user.username
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/books/<int:book_id>', methods=['PUT'])
@token_required
@admin_required
def update_book(current_user, book_id):
    """PUT /api/books/1 - Update book (admin only)"""
    try:
        book = Book.query.get(book_id)
        if book is None:
            return jsonify({
                'success': False,
                'error': 'Book not found'
            }), 404
        
        data = request.get_json()
        
        # Update book fields
        if 'title' in data:
            book.title = data['title']
        if 'author' in data:
            book.author = data['author']
        if 'isbn' in data:
            book.isbn = data['isbn']
        if 'price' in data:
            book.price = float(data['price'])
        if 'description' in data:
            book.description = data['description']
        if 'genre' in data:
            book.genre = data['genre']
        if 'publication_date' in data:
            book.publication_date = datetime.strptime(data['publication_date'], '%Y-%m-%d').date()
        if 'stock_quantity' in data:
            book.stock_quantity = data['stock_quantity']
        
        book.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'data': book.to_dict(),
            'message': 'Book updated successfully',
            'updated_by': current_user.username
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/books/<int:book_id>', methods=['DELETE'])
@token_required
@admin_required
def delete_book(current_user, book_id):
    """DELETE /api/books/1 - Delete book (admin only)"""
    try:
        book = Book.query.get(book_id)
        if book is None:
            return jsonify({
                'success': False,
                'error': 'Book not found'
            }), 404
        
        db.session.delete(book)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Book deleted successfully',
            'deleted_by': current_user.username
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# ===============================
# UTILITY ENDPOINTS
# ===============================

@app.route('/api/health', methods=['GET'])
def health_check():
    """GET /api/health - Check if API is running"""
    return jsonify({
        'success': True,
        'message': 'Bookstore API with JWT Authentication is running!',
        'version': '2.0.0'
    }), 200

# ===============================
# ERROR HANDLERS
# ===============================

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        'success': False,
        'error': 'Endpoint not found'
    }), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({
        'success': False,
        'error': 'Internal server error'
    }), 500

# ===============================
# RUN THE APPLICATION
# ===============================

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)