# Deployment and Demo Guide

This doc has a **Technical Runbook** and a **Simple Demo Breakdown**.

---

## Technical Runbook

### Run scripts
- Backend
  - Windows: `scripts\run_backend.bat`
  - Mac/Linux: `bash scripts/run_backend.sh`
- Frontend
  - Windows: `scripts\run_frontend.bat`
  - Mac/Linux: `bash scripts/run_frontend.sh`

### Endpoints (high level)
- **Auth**
  - `POST /api/register` → `{ success, user, token }`
  - `POST /api/login` → `{ success, user, token }`
  - `GET  /api/profile` → current user (requires token)
- **Books**
  - `GET  /api/books` → all books
  - `GET  /api/books/:id` → single book
  - `POST /api/books` → admin only
  - `PUT  /api/books/:id` → admin only
  - `DELETE /api/books/:id` → admin only
- **Sales**
  - `POST /api/sales` → creates a sale from cart items
  - `GET  /api/sales` → admin only (all sales)
  - `GET  /api/sales/user` → current user’s sales
  - `GET  /api/sales/count` → total count + recent sales
  - `GET  /api/sales/:id` → **order tracking** (buyer or admin)
- **Notifications**
  - `GET  /api/notifications` → list (admin only, supports `?unseen=1`)
  - `POST /api/notifications/:id/ack` → mark seen (admin only)
- **Password reset**
  - `POST /api/password-reset/request` → create reset token (demo: token returned in JSON)
  - `POST /api/password-reset/confirm` → set new password using token
- **System**
  - `GET /api/health` → `{ success: true }` for quick check

### Quick checks (browser)
- `http://localhost:5000/api/health` → JSON with `"success": true`
- `http://localhost:5000/api/books` → list of books

---

## Simple Demo Breakdown

1. **Open the store:** `http://localhost:8080`.
2. **Login/Register:** Create or log into a user.
3. **Browse books:** Show catalog → details page.
4. **Add to cart:** Add a book → cart shows entry.
5. **Remove item:** Delete from cart → confirm update.
6. **Checkout:** Add book(s) → complete checkout → see receipt.  
   - If stock drops below 5, a low-stock alert is logged.
7. **Order tracking:** Open `order-tracking.html`, enter a Sale ID, fetch order details.
8. **Notifications:** Admin logs in → open `notifications.html` → see unseen low-stock/out-of-stock notifications.
9. **Password reset (demo):**  
   - Request reset with an existing email → backend returns token.  
   - Confirm reset using token + new password → login with new password.

---

## Packaging (submission)
- Ensure `README.md`, `DEPLOYMENT.md`, `/backend`, `/frontend`, `/scripts`, `/build` are present.
- Exclude `.venv`, `backend/instance/`, and any `*.db` files.
- Zip the repo as `CS492_GP4.ZIP`.
