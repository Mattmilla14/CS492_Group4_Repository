# Bookstore Management System — CS492 Group 4

Frontend: static HTML/JS in `/frontend` (calls `http://localhost:5000/api`).  
Backend: Flask in `/backend` using SQLite (auto-created in `/backend/instance/bookstore.db`).

## Quick start
1. Python 3.10+ installed.
2. From repo root, start the backend:
   - Windows: `scripts\run_backend.bat`
   - macOS/Linux: `bash scripts/run_backend.sh`
3. In another terminal, start the frontend:
   - Windows: `scripts\run_frontend.bat`
   - macOS/Linux: `bash scripts/run_frontend.sh`
4. Visit `http://localhost:8080/`.

## Core features
- User registration and login (JWT tokens).
- Role-based access (admin vs. user).
- Catalog browsing and book details.
- Cart and checkout flow.
- Sales history for user and admin.
- **Order tracking:** `/api/sales/:id` endpoint + UI page.
- **Notifications (admin only):** low-stock and out-of-stock events logged, viewable in UI.
- **Password reset (demo):** token-based reset (token returned in response for demo).

## Notes
- Database file is created automatically in `/backend/instance/`.
- Do not commit `backend/instance/` or any `*.db` files.
- Exclude `.venv/` from version control; recreate with `pip install -r requirements.txt`.
