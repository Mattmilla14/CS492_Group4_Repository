#!/usr/bin/env bash
set -e
cd frontend
python -m http.server 8080
